<?php
require '../../../connection.php';
include '../../session.php';
?>

<div class="sidebar-logo">
  <a href="../../../">Amansa Travel</a>
</div>
<ul class="sidebar-nav">
  <li class="sidebar-header">Admin Elements</li>
  <li class="sidebar-item">
    <a href="../../../index.php" class="sidebar-link">
      <i class="fa-solid fa-list pe-2"></i>
      Dashboard
    </a>
  </li>
  <li class="sidebar-item">
    <a href="#" class="sidebar-link collapsed" data-bs-target="#listGambar" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-solid fa-file-lines pe-2"></i>
      List Gambar
    </a>
    <ul id="listGambar" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
      <li class="sidebar-item">
        <a href="../homePage/homePage.php" class="sidebar-link">Home Page</a>
      </li>
      <li class="sidebar-item">
        <a href="../paketUmroh/paketUmroh.php" class="sidebar-link">Paket Umroh</a>
      </li>

      <li class="sidebar-item">
        <a href="../paketHaji/paketHaji.php" class="sidebar-link">Paket Haji</a>
      </li>
      <li class="sidebar-item">
        <a href="../paketHajiKhusus/paketHajiKhusus.php" class="sidebar-link">Paket Haji Khusus</a>
      </li>
      <li class="sidebar-item">
        <a href="../Galeri/photoGaleri.php" class="sidebar-link">Galeri</a>
      </li>

      <li class="sidebar-item">
        <a href="../badal/badalHaji.php" class="sidebar-link">Badal</a>
      </li>
      <li class="sidebar-item">
        <a href="../kemitraan/kemitraan.php" class="sidebar-link">Kemitraan</a>
      </li>
      <li class="sidebar-item">
        <a href="../tabura/tabura.php" class="sidebar-link">Tabungan Umroh</a>
      </li>
    </ul>

    
  </li>
  <li class="sidebar-item">
    <a href="#" class="sidebar-link collapsed" data-bs-target="#auth" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-regular fa-user pe-2"></i>
      Auth
    </a>
    <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
      <li class="sidebar-item">
        <a href="../../loginPage" class="sidebar-link">Login</a>
      </li>
      <li class="sidebar-item">
        <a href="../../registerPage/register.php" class="sidebar-link">Register</a>
      </li>
      <li class="sidebar-item">
        <a href="../../loginPage/logout.php" class="sidebar-link">Log Out</a>
      </li>
    </ul>
  </li>
</ul>