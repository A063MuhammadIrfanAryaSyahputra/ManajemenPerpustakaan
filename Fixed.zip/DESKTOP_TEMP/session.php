<?php
  session_start();

  // Check if the user is logged in, if not redirect to login page
  if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
      header("Location: Admin/loginPage");
      exit;
  }

  // Display secure content here
?>