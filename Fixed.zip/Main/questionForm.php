<!DOCTYPE html>
<html lang="en" data-bs-theme="light">

<head>
    <meta charset="UTF-8">
    <title>Hubungi Kami</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/tentang.css" />
    

</head>

<body>

    <?php include 'navbarAmansa.php'; ?>

    <div class="container d-flex flex-column align-items-center">
        <h1 style="color: gold;">Informasi Lanjut</h1>
        <div class="col-md-6">
            <div class="form-reg card p-4">
                <form action="emailQuestion/send_email.php" method="post">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nama:</label>
                        <input type="text" id="name" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email atau No HP:</label>
                        <input type="text" id="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="pesan" class="form-label">Pesan atau Pertanyaan:</label>
                        <textarea id="pesan" name="pesan" class="form-control" required></textarea>
                    </div>
                    <div class="d-grid">
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Kirim</button>
                            <button type="cancel" class="btn btn-warning"
                                onclick="window.history.back()">Kembali</button>

                        </div>



                    </div>
                </form>
            </div>
        </div>
    </div>
    <br>

    <?php include 'footerTentang.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+3oVBZC5c8EpJfJNpeVf5h0TGZnXz"
        crossorigin="anonymous"></script>
</body>

</html>