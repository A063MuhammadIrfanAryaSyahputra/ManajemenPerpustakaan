<!doctype html>
<html lang="en">
    <head>
        <title>Whatsapp Widget</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="wa/src/css/whatsapp-widget.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="background-color:;">
        <script src="wa/src/js/whatsapp-widget.js"></script>
        <script>
            initWidget()
        </script>
    </body>
</html>
