<?php
require '../connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <title>Umroh</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link rel="stylesheet" type="text/css" href="css/tentang.css" />
  <!-- <link rel="stylesheet" type="text/css" href="css/navbar.css" /> -->


</head>

<style>
  .parallax-inner {
    padding: 20% 0;
  }


  .h1,
  h1 {
    color: #0D3C63;
  }

  .button33{
    border-color: aquamarine;
  }



  .parallax-1 {
    background-image: url("assets/umrooh.png");
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    margin-bottom: 4%;
  }

  .paketUmroh {
  height: 550px;
  /* background-color: rgb(255, 20, 12); */
  padding: 1em;
  font-weight: 700;
  color: black;
  text-align: center;
  /* border: 10px solid rgb(24, 24, 24); */
  border-radius: 10px;
  width: 350px;
  
}
</style>

<body>


  <?php include 'navbarAmansa.php'; ?>



  <div class="parallax-1">
        <div class="parallax-inner">

          <h1 style="font-family: Spinnaker; font-size: 35px; font-weight: bold;;">Umrah bersama Amansa</h1>
          <h2 style="font-family: Spinnaker; font-size: 35px; font-weight: bold;"><em>Special Spiritual Moment to Baitullah</em></h2>
        </div>
      </div>

      <div class="cara-pendaftaran-section">
  <h2 class="section-title">Cara Pendaftaran</h2>
  <div class="steps-image">
    <img src="../Admin/img/cara1.png" alt="Cara Pendaftaran" class="cara-pendaftaran-img">
    <img src="../Admin/img/cara2.png" alt="Cara Pendaftaran" class="cara-pendaftaran-img">
  </div>
</div>


  <div class="containerUmroh">
    <h1>Layanan Umroh Kami</h1>
    <br><br>
    <div class="containerPaketUmroh row justify-content-center">
      <div class="paketUmroh">
        <?php
        $i = 1;
        $rows = mysqli_query($conn, "SELECT * FROM umroh WHERE id = 5"); ?>
        <?php foreach ($rows as $row) : ?>
          <tr>
            <td>
              <!-- <h1><?php echo $row["nama"]; ?></h1> -->
            </td>
            <div class="containerCoverUmroh">
              <td><img src="../Admin/img/<?php echo $row['cover']; ?>" alt=""></td>
            </div>
            <?php
            echo
            "<td><a href='paketUmroh.php?id=" . $row['id'] . "' class='button33'>Lihat Selengkapnya</a> </td>" ?>
          </tr>
        <?php endforeach; ?>
      </div>
      <div class="paketUmroh">
        <?php
        $i = 1;
        $rows = mysqli_query($conn, "SELECT * FROM umroh WHERE id = 6"); ?>
        <?php foreach ($rows as $row) : ?>
          <tr>
            <td>
              <!-- <h1><?php echo $row["nama"]; ?></h1> -->
            </td>
            <div class="containerCoverUmroh">
              <td><img src="../Admin/img/<?php echo $row['cover']; ?>" alt=""></td>
            </div>
            <?php
            echo
            "<td><a href='paketUmroh.php?id=" . $row['id'] . "' class='button33'>Lihat Selengkapnya</a> </td>" ?>
          </tr>
        <?php endforeach; ?>
      </div>
      <div class="paketUmroh">
        <?php
        $i = 1;
        $rows = mysqli_query($conn, "SELECT * FROM umroh WHERE id = 7"); ?>
        <?php foreach ($rows as $row) : ?>
          <tr>
            <td>
              <!-- <h1><?php echo $row["nama"]; ?></h1> -->
            </td>
            <div class="containerCoverUmroh">
              <td><img src="../Admin/img/<?php echo $row['cover']; ?>" alt=""></td>
            </div>
            <?php
            echo
            "<td><a href='paketUmroh.php?id=" . $row['id'] . "' class='button33'>Lihat Selengkapnya</a> </td>" ?>
          </tr>
        <?php endforeach; ?>
      </div>
      <div class="paketUmroh">
        <?php
        $i = 1;
        $rows = mysqli_query($conn, "SELECT * FROM umroh WHERE id = 8"); ?>
        <?php foreach ($rows as $row) : ?>
          <tr>
            <td>
              <!-- <h1><?php echo $row["nama"]; ?></h1> -->
            </td>
            <div class="containerCoverUmroh">
              <td><img src="../Admin/img/<?php echo $row['cover']; ?>" alt=""></td>
            </div>
            <?php
            echo
            "<td><a href='paketUmroh.php?id=" . $row['id'] . "' class='button33'>Lihat Selengkapnya</a> </td>" ?>
          </tr>
        <?php endforeach; ?>
      </div>
      <div class="paketUmroh">
        <?php
        $i = 1;
        $rows = mysqli_query($conn, "SELECT * FROM umroh WHERE id = 9"); ?>
        <?php foreach ($rows as $row) : ?>
          <tr>
            <td>
              <!-- <h1><?php echo $row["nama"]; ?></h1> -->
            </td>
            <div class="containerCoverUmroh">
              <td><img src="../Admin/img/<?php echo $row['cover']; ?>" alt=""></td>
            </div>
            <?php
            echo
            "<td><a href='paketUmroh.php?id=" . $row['id'] . "' class='button33'>Lihat Selengkapnya</a> </td>" ?>
          </tr>
        <?php endforeach; ?>
      </div>
      <div class="paketUmroh">
        <?php
        $i = 1;
        $rows = mysqli_query($conn, "SELECT * FROM umroh WHERE id = 10"); ?>
        <?php foreach ($rows as $row) : ?>
          <tr>
            <td>
            </td>
            <div class="containerCoverUmroh">
              <td><img src="../Admin/img/<?php echo $row['cover']; ?>" alt=""></td>
            </div>
            <?php
            echo
            "<td><a href='paketUmroh.php?id=" . $row['id'] . "' class='button33'>Lihat Selengkapnya</a> </td>" ?>
          </tr>
        <?php endforeach; ?>

      </div>
      <br>
    </div>
  </div>

  <section class="achievementss">
    <br><br><br><br><br>

    </div>
  </section>


  <?php include 'footerAmansa.php'; ?>

  <script src="js/script.js"></script>
  
</body>

</html>